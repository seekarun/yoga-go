"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// lambda/calel-post-confirmation.ts
var calel_post_confirmation_exports = {};
__export(calel_post_confirmation_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(calel_post_confirmation_exports);
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_client_cognito_identity_provider = require("@aws-sdk/client-cognito-identity-provider");
var import_crypto = require("crypto");
var dynamoClient = new import_client_dynamodb.DynamoDBClient({});
var cognitoClient = new import_client_cognito_identity_provider.CognitoIdentityProviderClient({});
var TABLE_NAME = process.env.TABLE_NAME || "calel-core";
function generateTenantId() {
  return `ten_${(0, import_crypto.randomBytes)(12).toString("hex")}`;
}
function generateApiKey() {
  const prefix = `ck_${(0, import_crypto.randomBytes)(4).toString("hex")}`;
  const secret = (0, import_crypto.randomBytes)(24).toString("hex");
  const key = `${prefix}_${secret}`;
  const hash = (0, import_crypto.createHash)("sha256").update(key).digest("hex");
  return { key, prefix, hash };
}
function generateSlug(email) {
  const emailPart = email.split("@")[0];
  return emailPart.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").substring(0, 50);
}
async function isSlugTaken(slug) {
  const result = await dynamoClient.send(
    new import_client_dynamodb.QueryCommand({
      TableName: TABLE_NAME,
      IndexName: "GSI1",
      KeyConditionExpression: "GSI1PK = :pk",
      ExpressionAttributeValues: {
        ":pk": { S: `TENANT#SLUG#${slug.toLowerCase()}` }
      },
      Limit: 1
    })
  );
  return (result.Items?.length ?? 0) > 0;
}
async function getUniqueSlug(baseSlug) {
  let slug = baseSlug;
  let counter = 1;
  while (await isSlugTaken(slug)) {
    slug = `${baseSlug}-${counter}`;
    counter++;
    if (counter > 100) {
      slug = `${baseSlug}-${(0, import_crypto.randomBytes)(4).toString("hex")}`;
      break;
    }
  }
  return slug;
}
var handler = async (event) => {
  console.log("[DBG][calel-post-confirmation] Event:", JSON.stringify(event));
  if (event.triggerSource !== "PostConfirmation_ConfirmSignUp") {
    console.log(
      "[DBG][calel-post-confirmation] Skipping, not a signup confirmation"
    );
    return event;
  }
  const { userPoolId, userName } = event;
  const email = event.request.userAttributes.email;
  const givenName = event.request.userAttributes.given_name || "";
  const familyName = event.request.userAttributes.family_name || "";
  console.log("[DBG][calel-post-confirmation] Creating tenant for:", email);
  try {
    const tenantId = generateTenantId();
    const { prefix: apiKeyPrefix, hash: apiKeyHash } = generateApiKey();
    const baseSlug = generateSlug(email);
    const slug = await getUniqueSlug(baseSlug);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const tenantName = givenName ? `${givenName}${familyName ? " " + familyName : ""}` : email.split("@")[0];
    await dynamoClient.send(
      new import_client_dynamodb.PutItemCommand({
        TableName: TABLE_NAME,
        Item: {
          PK: { S: "TENANT" },
          SK: { S: tenantId },
          GSI1PK: { S: `TENANT#SLUG#${slug.toLowerCase()}` },
          GSI1SK: { S: tenantId },
          entityType: { S: "TENANT" },
          id: { S: tenantId },
          name: { S: tenantName },
          slug: { S: slug },
          apiKey: { S: apiKeyHash },
          apiKeyPrefix: { S: apiKeyPrefix },
          ownerEmail: { S: email.toLowerCase() },
          ownerCognitoSub: { S: userName },
          settings: {
            M: {
              defaultTimezone: { S: "UTC" },
              allowPublicBooking: { BOOL: true },
              requireEmailVerification: { BOOL: false }
            }
          },
          status: { S: "active" },
          createdAt: { S: now },
          updatedAt: { S: now }
        },
        ConditionExpression: "attribute_not_exists(PK)"
      })
    );
    console.log("[DBG][calel-post-confirmation] Tenant created:", tenantId);
    await dynamoClient.send(
      new import_client_dynamodb.PutItemCommand({
        TableName: TABLE_NAME,
        Item: {
          PK: { S: `APIKEY#${apiKeyPrefix}` },
          SK: { S: tenantId },
          GSI1PK: { S: `APIKEY#${apiKeyPrefix}` },
          GSI1SK: { S: tenantId },
          tenantId: { S: tenantId },
          apiKeyHash: { S: apiKeyHash },
          entityType: { S: "API_KEY_LOOKUP" }
        }
      })
    );
    console.log("[DBG][calel-post-confirmation] API key lookup created");
    await cognitoClient.send(
      new import_client_cognito_identity_provider.AdminUpdateUserAttributesCommand({
        UserPoolId: userPoolId,
        Username: userName,
        UserAttributes: [
          { Name: "custom:tenantId", Value: tenantId },
          { Name: "custom:tenantName", Value: tenantName }
        ]
      })
    );
    console.log("[DBG][calel-post-confirmation] User attributes updated");
  } catch (error) {
    console.error("[DBG][calel-post-confirmation] Error:", error);
  }
  return event;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
